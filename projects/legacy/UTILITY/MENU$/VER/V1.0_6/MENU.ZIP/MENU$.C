/* ver    description
 * -----------------------------------------------------------------------
 * 1.0.6 - uses a batch file to invoke menu selector; runs on any hardware
 * 1.0.5 - looks for environment variable MENU to change colors
 * 1.0.4 - creates batch file to execute commands; thus, 0 bytes used
 * 1.0.3 - allow attributes to be specified at command line
 * 1.0.2 - optimize routines to use less memory
 * 1.0.1 - add ability to have multiple commands per choice
 * 1.0.0 - original program that lists and executes user selections
 */

#include <bios.h>
#include <conio.h>
#include <ctype.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* BIOS interrupts */
#define VIDEO_IO	0x10

/* BIOS video routines */
#define CUR_POS		2
#define SCROLL_UP	6
#define READ_CA		8
#define WRITE_CA	9
#define GET_STATE	15

/* DOS interrupts */
#define BDOS_REQ	0x21

/* DOS functions */
#define GET_TIME	0x2C

/* attribute modifiers */
#define BRIGHT		8
#define BLINK		128

/* primary video attributes */
#define BLU		1
#define GRN		2
#define RED		4

/* composite video attributes */
#define BLK		0
#define CYN		(BLU | GRN)		/* 3 */
#define MAG		(BLU | RED)		/* 5 */
#define BRN		(GRN | RED)		/* 6 */
#define WHT		(BLU | GRN | RED)	/* 7 */
#define GRAY		(BLK | BRIGHT)
#define LBLU		(BLU | BRIGHT)
#define LGRN		(GRN | BRIGHT)
#define LCYAN		(CYN | BRIGHT)
#define LRED		(RED | BRIGHT)
#define LMAG		(MAG | BRIGHT)
#define YEL		(BRN | BRIGHT)
#define BWHT		(WHT | BRIGHT)
#define NORMAL		WHT
#define REVERSE		112

/*
 * drawing characters -- items having two numbers use the first number as
 * the horizontal specifier
 */

/* double-line boxes */
#define VBAR2		186
#define HBAR2		205
#define ULC22		201
#define URC22		187
#define LLC22		200
#define LRC22		188
#define TL22		204
#define TR22		185
#define TT22		203
#define TB22		202
#define X22		206

/* full and partial blocks */
#define BLOCK		219
#define VBAR		219		/* alias */
#define VBARL		221
#define VBARR		222
#define HBART		223
#define HBARB		220

/* values for special keys on IBM PC and clones   */
#define XF		0x100		/* extended key flag */

#define K_HOME		(71 | XF)	/* cursor keypad (NumLock off; not shifted) */
#define K_END		(79 | XF)
#define K_PGUP		(73 | XF)
#define K_PGDN		(81 | XF)
#define K_LEFT		(75 | XF)
#define K_RIGHT		(77 | XF)
#define K_UP		(72 | XF)
#define K_DOWN		(80 | XF)

#define K_ESC		27		/* miscellaneous special keys */
#define K_SPACE		32
#define K_RETURN	13

#define K_NULL		(192 | XF)

#define MENU_DAT	"MENU.DAT"
#define MENU_SIG	"MENU  Version 1.0.6  Copyright (c) 1990 Vorne Industries Incorporated"

typedef unsigned char	Byte;
typedef unsigned long	DWord;

typedef enum { false, true } Boolean;

#define SCREEN_HEIGHT	25
#define SCREEN_WIDTH	80

#define DELIMETERS	" ,\t\n"
#define COMMENT		';'
#define QUOTE		'"'

#define TOK_BUFF_SIZE	256
#define MAX_ITEMS	23

#define SAVER_DELAY	66000L		/* 11 minutes */

#define BOX_TOP_LEF	ULC22
#define BOX_TOP_MID	HBAR2
#define BOX_TOP_RIG	URC22
#define BOX_MID_LEF	VBAR2
#define BOX_MID_RIG	VBAR2
#define BOX_BOT_LEF	LLC22
#define BOX_BOT_MID	HBAR2
#define BOX_BOT_RIG	LRC22

enum {	EXIT_OK,		/* no errors */
	EXIT_CANCEL,		/* escape key pressed to exit menu */
	EXIT_NOT_FOUND,		/* menu data file not found */
	EXIT_NO_ITEMS,		/* no items listed in data file */
	EXIT_NOT_WRITE		/* cannot open file for writing */
	};

enum { A_LOW, A_HIGH, A_CLS, A_INV, A_MAX };

static short	vpage=0;
static char	tokBuff[TOK_BUFF_SIZE+1];
static short	numMenuItems=0, lenMenuItems=0;
static char	*menuItem[MAX_ITEMS], *menuCommand[MAX_ITEMS];
static short	mAttr[] = { BRN, YEL, WHT, 0x78 };


static void	MenuDo(void);
static void	MenuRead(void);

static void	DrawBox(short t, short l, short b, short r, short a);
static Boolean	elapsed(DWord jtime);
static Boolean	GetToken(FILE *fp);
static Boolean	In(char c, register char *delim);
static short	InKey(void);
static DWord	jiffy(void);
static short	KeyboardGetKey(void);
static void	VideoClearScreen(void);
static short	VideoGetMode(void);
static void	VideoHideCursor(void);
static void	VideoPutAttr(short row, short col, short attr, short num);
static void	VideoPutCharAttr(short row, short col, short ch, short attr, short num);
static void	VideoPutStrAttr(short row, short col, char *s, short attr);


int main() {
	char	*env;
	short	i;

	env = strtok(getenv("MENU"), ",");
	for (i=0; env && i<A_INV; i++) {
		mAttr[i] = atoi(env);
		env = strtok(NULL, ",");
		}
	mAttr[A_INV] = (VideoGetMode() == 7) ? 0x78 : ((mAttr[A_LOW]<<4) & REVERSE) | mAttr[A_HIGH];
	MenuRead();
	MenuDo();
	return (EXIT_SUCCESS);
	}


static void DrawBox(short top, short lef, short bot, short rig, short attr) {
	short	i, x;

	x = rig - lef - 1;
	VideoPutCharAttr(top, lef, BOX_TOP_LEF, attr, 1);
	VideoPutCharAttr(top, lef+1, BOX_TOP_MID, attr, x);
	VideoPutCharAttr(top, rig, BOX_TOP_RIG, attr, 1);
	for (i = top+1; i < bot; ++i) {
		VideoPutCharAttr(i, lef, BOX_MID_LEF, attr, 1);
		VideoPutCharAttr(i, rig, BOX_MID_RIG, attr, 1);
		}
	VideoPutCharAttr(bot, lef, BOX_BOT_LEF, attr, 1);
	VideoPutCharAttr(bot, lef+1, BOX_BOT_MID, attr, x);
	VideoPutCharAttr(bot, rig, BOX_BOT_RIG, attr, 1);
	}


/*
 * elapsed -- returns true if jtime is less than the current time or if
 * jtime is greater than 23:00 and current time is less than 1:00.  The
 * reason for this second criteria is to handle the case of comparing
 * the time between midnight.
 */

static Boolean elapsed(DWord jtime) {
	static DWord	newJif=0;
	DWord		oldJif;

	oldJif = newJif;
	newJif = jiffy();
	return (newJif > jtime || newJif < oldJif);
	}


static Boolean GetToken(FILE *fp) {
	static short	ch=' ';
	register short	len;
	register char	*tok;

	len = TOK_BUFF_SIZE;
	tok = tokBuff;
	while (ch != EOF) {
		ch = fgetc(fp);
		if (ch == EOF)
			break;
		if (ch == COMMENT)
			while ((ch=fgetc(fp)) != '\n')
				;
		else if (!In(ch, DELIMETERS))
			break;
		}
	if (ch == EOF) {
		*tok = '\0';
		return(false);
		}
	if (ch == QUOTE) {
		while ((--len>0) && ((ch=fgetc(fp))!=EOF) && (ch!=QUOTE) && (ch!='\n'))
			*tok++ = ch;
		}
	else
		do {
			*tok++ = ch;
			ch = fgetc(fp);
			} while ((--len>0) && ch!=EOF && !In(ch, DELIMETERS));
	*tok = '\0';
	return(true);
	}


/*
 * in -- test for character in string.  Returns true if character found.
 */

static Boolean In(char c, register char *delim) {
	register char	ch;

	ch = c;
	while (*delim)
		if (ch == *delim++)
			return (true);
	return(false);
	}


static short InKey(void) {
	DWord	nextTime;

	nextTime = jiffy() + SAVER_DELAY;
	while (!bioskey(1)) {
		if (elapsed(nextTime)) {
			VideoClearScreen();
			while (!bioskey(1))
				;
			KeyboardGetKey();
			return (K_NULL);
			}
		}
	return (KeyboardGetKey());
	}


static DWord jiffy(void) {
	union REGS	r;

	r.h.ah = GET_TIME;
	int86(BDOS_REQ, &r, &r);
	return ((DWord)r.h.dl + ((DWord)r.h.dh * 100L) + ((DWord)r.h.cl * 6000L) + ((DWord)r.h.ch * 360000L));
	}


static short KeyboardGetKey(void) {
	short	ch;

	ch = bioskey(0);
	if (ch & 0x00FF)
		return (ch & 0x00FF);
	return ((ch >> 8) | XF);
	}


static void MenuDo(void) {
	short	top, lef, bot, rig, i, curPtr, nextPtr, len;
	Boolean	done1, done2;
	short	ch;
	char	*s, *t, command[TOK_BUFF_SIZE];
	FILE	*fptr;

	top = 11 - (numMenuItems / 2);
	bot = top + numMenuItems + 1;
	lef = 37 - (lenMenuItems / 2);
	rig = lef + lenMenuItems + 3;
	done1 = false;
	while (!done1) {
		VideoClearScreen();
		DrawBox(top, lef, bot, rig, mAttr[A_LOW]);
		for (i=0; i<numMenuItems; i++)
			VideoPutStrAttr(top+i+1, lef+2, menuItem[i], mAttr[A_HIGH]);
		len = lenMenuItems+2;
		curPtr = -1;
		nextPtr = 0;
		done2 = false;
		while (!done2) {
			if (nextPtr != curPtr) {
				if (curPtr >= 0)
					VideoPutAttr(top+1+curPtr, lef+1, mAttr[A_HIGH], len);
				curPtr = nextPtr;
				VideoPutAttr(top+1+curPtr, lef+1, mAttr[A_INV], len);
				}
			VideoHideCursor();
			switch (ch = InKey()) {
				case K_ESC:
					VideoClearScreen();
					puts(MENU_SIG);
					exit(EXIT_CANCEL);
					break;
				case K_HOME:
					nextPtr = 0;
					break;
				case K_END:
					nextPtr = numMenuItems-1;
					break;
				case K_UP:
					if (curPtr > 0)
						nextPtr--;
					break;
				case K_DOWN:
					if (curPtr < numMenuItems-1)
						nextPtr++;
					break;
				case K_SPACE:
					if (curPtr == numMenuItems-1)
						nextPtr = 0;
					else
						nextPtr++;
					break;
				case K_RETURN:
					if ((fptr=fopen("$.bat", "wt")) == NULL)
						exit(EXIT_NOT_WRITE);
					VideoClearScreen();
					s = menuCommand[curPtr];
					while (*s) {
						t = command;
						while (*s && *s != ';')
							*t++ = *s++;
						*t = '\0';
						if (*s)
							s++;
						fputs(command, fptr);
						fputs("\n", fptr);
						}
					fputs("menu", fptr);
					fclose(fptr);
					done1 = done2 = true;
					break;
				case K_NULL:
					done2 = true;
					break;
				default:
					ch = toupper(ch);
					nextPtr = curPtr;
					i = 1;
					do {
						if (nextPtr < numMenuItems-1)
							nextPtr++;
						else
							nextPtr = 0;
						} while ((++i < numMenuItems) && (ch != *menuItem[nextPtr]));
					if (ch != *menuItem[nextPtr])
						nextPtr = curPtr;
					break;
				}
			}
		}
	VideoClearScreen();
	}


static void MenuRead(void) {
	FILE	*fptr;

	if ((fptr=fopen(MENU_DAT, "rt")) == NULL)
		exit(EXIT_NOT_FOUND);
	while (numMenuItems<MAX_ITEMS && GetToken(fptr)) {
		menuItem[numMenuItems] = strdup(tokBuff);
		lenMenuItems = max(strlen(tokBuff), lenMenuItems);
		GetToken(fptr);
		menuCommand[numMenuItems++] = strdup(tokBuff);
		}
	fclose(fptr);
	if (numMenuItems < 1)
		exit(EXIT_NO_ITEMS);
	}


static void VideoClearScreen(void) {
	_AH = SCROLL_UP;
	_AL = 0;			/* 0 = clear screen */
	_BH = mAttr[A_CLS];
	_CX = 0;
	_DH = SCREEN_HEIGHT-1;
	_DL = SCREEN_WIDTH-1;
	geninterrupt(VIDEO_IO);
	_AH = CUR_POS;
	_BH = vpage;
	_DX = 0;
	geninterrupt(VIDEO_IO);
	}


static short VideoGetMode(void) {
	short	mode;

	_AH = GET_STATE;
	geninterrupt(VIDEO_IO);
	mode = _AL;
	vpage = _BH;
	return (mode);
	}


static void VideoHideCursor(void) {
	_AH = CUR_POS;
	_BH = vpage;
	_DH = SCREEN_HEIGHT;
	_DL = 0;
	geninterrupt(VIDEO_IO);
	}


static void VideoPutAttr(short row, short col, short attr, short num) {
	short	i;

	i = 0;
	while (i++ < num) {
		_AH = CUR_POS;
		_BH = vpage;
		_DH = row;
		_DL = col++;
		geninterrupt(VIDEO_IO);
		_AH = READ_CA;
		_BH = vpage;
		geninterrupt(VIDEO_IO);
		_AH = WRITE_CA;
		_BH = vpage;
		_BL = attr;
		_CX = 1;
		geninterrupt(VIDEO_IO);
		}
	}


static void VideoPutCharAttr(short row, short col, short ch, short attr, short num) {
	_AH = CUR_POS;
	_BH = vpage;
	_DH = row;
	_DL = col;
	geninterrupt(VIDEO_IO);
	_AH = WRITE_CA;
	_AL = ch;
	_BH = vpage;
	_BL = attr;
	_CX = num;
	geninterrupt(VIDEO_IO);
	}


static void VideoPutStrAttr(short row, short col, char *s, short attr) {
	while (*s) {
		_AH = CUR_POS;
		_BH = vpage;
		_DH = row;
		_DL = col++;
		geninterrupt(VIDEO_IO);
		_AH = WRITE_CA;
		_AL = *s++;
		_BH = vpage;
		_BL = attr;
		_CX = 1;
		geninterrupt(VIDEO_IO);
		}
	}
