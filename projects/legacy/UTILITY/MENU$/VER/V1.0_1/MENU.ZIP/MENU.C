/* menu.c -- September 7, 1989 */

/* ver    description
 * -----------------------------------------------------------------------
 * 1.01 - add ability to have multiple commands per choice
 * 1.00 - original program that lists and executes user selections
 */

/* ---------------------------------------------------------------------- *
 * MODIFICATIONS
 *  Jack Niewiadomski   07-SEP-1989
 * ---------------------------------------------------------------------- */

#include <conio.h>
#include <ctype.h>
#include <dos.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "menu.h"

#define MENU_DAT "MENU.DAT"

typedef unsigned char UCHAR;
typedef unsigned long ULONG;

typedef UCHAR BOOLEAN;

#define FALSE 0
#define TRUE  1

#define SCREEN_HEIGHT 25
#define SCREEN_WIDTH  80

#define DELIMETERS   " ,\t\n\f"
#define COMMENT      ';'
#define QUOTE        '"'

#define BUF_SIZE     256
#define MAX_ITEMS    23


#define SAVER_TEXT   "*** Screen Saver ***"
#define SAVER_DELAY  66000L   /* 11 minutes */
#define SAVER_RATE   16

#define BOX_TOP_LEF  ULC22
#define BOX_TOP_MID  HBAR2
#define BOX_TOP_RIG  URC22
#define BOX_MID_LEF  VBAR2
#define BOX_MID_MID  ' '
#define BOX_MID_RIG  VBAR2
#define BOX_BOT_LEF  LLC22
#define BOX_BOT_MID  HBAR2
#define BOX_BOT_RIG  LRC22

typedef enum {
  ERR_BAD_DOS,
  ERR_OUT_OF_MEM
  } ERROR;

static short Vpage=0, mLow, mHigh, mInv;
static char  buff[BUF_SIZE+1];
static short numMenuItems=0, lenMenuItems=0;
static char  *menuItem[MAX_ITEMS], *menuCommand[MAX_ITEMS];


static void    cls(short top, short lef, short bot, short rig, short attr);
static void    doMenu(void);
static void    drawBox(short wtop, short wlef, short wbot, short wrig, short wcolor);
static BOOLEAN elapsed(ULONG jtime);
static void    getCharAttr(short *ch, short *attr);
static void    getCursor(short *v, short *h);
static short   getMode(void);
static int     inKey(void);
static int     getKey(void);
static BOOLEAN getToken(FILE *fp, char *tok, short len);
static BOOLEAN in(char c, char *delim);
static int     inKey(void);
static ULONG   jiffy(void);
static void    putAttr(short attr, short num);
static void    putCharAttr(short ch, short attr, short num);
static void    putCursor(short v, short h);
static void    putStrAttr(short v, short h, char *s, short attr);
static short   readData(void);


int main(void)
  {
    BOOLEAN ok;

    if (getMode() == 7) {
      mLow = WHT;
      mHigh = BWHT;
      mInv = 0x78;
      }
    else {
      mLow = BRN;
      mHigh = YEL;
      mInv = (mLow<<4) & REVERSE;
      }
    ok = readData();
    if (ok)
      doMenu();
    puts("MENU  Version 1.01  1989 by Vorne Industries Incorporated");
    if (!ok)
      puts("Unable to find file MENU.DAT");
    return (ok ? EXIT_SUCCESS : EXIT_FAILURE);
    }


static short readData(void)
  {
    FILE *fptr;

    if ((fptr=fopen(MENU_DAT, "rt")) == NULL)
      return (FALSE);
    while (numMenuItems<MAX_ITEMS && getToken(fptr, buff, BUF_SIZE)) {
      menuItem[numMenuItems] = (char *) malloc(strlen(buff)+1);
      strcpy(menuItem[numMenuItems], buff);
      lenMenuItems = max(strlen(buff), lenMenuItems);
      getToken(fptr, buff, BUF_SIZE);
      menuCommand[numMenuItems] = (char *) malloc(strlen(buff)+1);
      strcpy(menuCommand[numMenuItems], buff);
      numMenuItems++;
      }
    fclose(fptr);
    return (numMenuItems > 0);
    }


/* in -- test for character in string.  Returns TRUE if character found. */

static BOOLEAN in(char c, char *delim)
  {
    while (*delim)
      if (c == *delim++)
        return (TRUE);
    return(FALSE);
    }


static BOOLEAN getToken(FILE *fp, char *tok, short len)
  {
    static int ch=' ';

    while (ch != EOF) {
      ch = fgetc(fp);
      if (ch == EOF)
        break;
      if (ch == COMMENT)
        while ((ch=fgetc(fp)) != '\n')
          ;
      else if (!in(ch, DELIMETERS))
        break;
      }
    if (ch == EOF) {
      *tok = '\0';
      return(FALSE);
      }
    if (ch == QUOTE) {
      while ((--len>0) && ((ch=fgetc(fp))!=EOF) && (ch!=QUOTE) && (ch!='\n'))
        *tok++ = ch;
      }
    else
      do {
        *tok++ = ch;
        ch = fgetc(fp);
        } while ((--len>0) && ch!=EOF && !in(ch, DELIMETERS));
    *tok = '\0';
    return(TRUE);
    }


static void doMenu(void)
  {
    short   top, lef, bot, rig, i, curPtr, nextPtr, len;
    BOOLEAN done1, done2;
    int     ch;
    char    *s, *t, command[BUF_SIZE];

    top = 11 - (numMenuItems / 2);
    bot = top + numMenuItems + 1;
    lef = 37 - (lenMenuItems / 2);
    rig = lef + lenMenuItems + 3;
    done1 = FALSE;
    while (!done1) {
      cls(0, 0, SCREEN_HEIGHT-1, SCREEN_WIDTH-1, mLow);
      drawBox(top, lef, bot, rig, mLow);
      for (i=0; i<numMenuItems; i++)
        putStrAttr(top+i+1, lef+2, menuItem[i], mHigh);
      len = lenMenuItems+2;
      curPtr = -1;
      nextPtr = 0;
      done2 = FALSE;
      while (!done2) {
        if (nextPtr != curPtr) {
          if (curPtr >= 0) {
            putCursor(top+1+curPtr, lef+1);
            putAttr(mHigh, len);
            }
          curPtr = nextPtr;
          putCursor(top+1+curPtr, lef+1);
          putAttr(mInv, len);
          }
        putCursor(25, 1);
        switch (ch = inKey()) {
          case K_ESC    : done1 = done2 = TRUE;
                          break;
          case K_HOME   : nextPtr = 0;
                          break;
          case K_END    : nextPtr = numMenuItems-1;
                          break;
          case K_UP     : if (curPtr > 0)
                            nextPtr--;
                          break;
          case K_DOWN   : if (curPtr < numMenuItems-1)
                            nextPtr++;
                          break;
          case K_SPACE  : if (curPtr == numMenuItems-1)
                            nextPtr = 0;
                          else
                            nextPtr++;
                          break;
          case K_RETURN : cls(0, 0, SCREEN_HEIGHT-1, SCREEN_WIDTH-1, mLow);
                          putCursor(0, 0);
                          s = menuCommand[curPtr];
                          while (*s) {
                            t = command;
                            while (*s && *s != ';')
                              *t++ = *s++;
                            *t = '\0';
                            if (*s)
                              s++;
                            system(command);
                            }
                          done2 = TRUE;
                          break;
          default       : ch = toupper(ch);
                          nextPtr = curPtr;
                          i = 1;
                          if (nextPtr < numMenuItems-1)
                            nextPtr++;
                          else
                            nextPtr = 0;
                          while ((++i < numMenuItems) && (ch != *menuItem[nextPtr]))
                            if (nextPtr < numMenuItems-1)
                              nextPtr++;
                            else
                              nextPtr=0;
                          if (ch != *menuItem[nextPtr])
                            nextPtr = curPtr;
                          break;
          }
        }
      }
    cls(0, 0, SCREEN_HEIGHT-1, SCREEN_WIDTH-1, WHT);
    putCursor(0, 0);
    }


/* cls -- clear specified region of the "visual" screen page. */

static void cls(short top, short lef, short bot, short rig, short attr)
  {
    _AH = SCROLL_UP;
    _AL = 0;                /* clear screen */
    _BH = attr;
    _CH = top;
    _CL = lef;
    _DH = bot;
    _DL = rig;
    geninterrupt(VIDEO_IO);
    }


/* getCharAttr -- read character and attribute at current position. */

static void getCharAttr(short *ch, short *attr)
  {
    _AH = READ_CHAR_ATTR;
    _BH = Vpage;
    geninterrupt(VIDEO_IO);
    *ch   = _AL;
    *attr = _AH;
    }


/* getCursor -- pass back the vertical and horizontal *
 * position of the cursor.                            */

static void getCursor(short *v, short *h)
  {
    _AH = GET_CUR;
    _BH = Vpage;
    geninterrupt(VIDEO_IO);
    *v = _DH;
    *h = _DL;
    }


/* getMode -- get current video mode. */

static short getMode(void)
  {
    short mode;

    _AH = GET_STATE;
    geninterrupt(VIDEO_IO);
    mode = _AL;
    Vpage = _BH;
    return (mode);
    }


/* putAttr -- write the attribute only (leave character undisturbed). */

static void putAttr(short attr, short num)
  {
    short v, h, ch, temp, i;

    getCursor(&v, &h);
    for (i=0; i<num; ++i) {
      putCursor(v, h+i);
      getCharAttr(&ch, &temp);
      putCharAttr(ch, attr, 1);
      }
    putCursor(v, h);
    }


/* putCharAttr -- write character and attribute to the screen. */

static void putCharAttr(short ch, short attr, short num)
  {
    _AH = WRITE_CHAR_ATTR;
    _AL = ch;
    _BH = Vpage;
    _BL = attr;
    _CX = num;
    geninterrupt(VIDEO_IO);
    }


/* putCursor -- put the cursor at the specified position (v, h). */

static void putCursor(short v, short h)
  {
    _AH = CUR_POS;
    _BH = Vpage;
    _DH = v;
    _DL = h;
    geninterrupt(VIDEO_IO);
    }


static void drawBox(short wtop, short wlef, short wbot, short wrig, short wcolor)
  {
    int i, x;

    x = wrig - wlef - 1;
    putCursor(wtop, wlef);                   /* draw the bottom top row */
    putCharAttr(BOX_TOP_LEF, wcolor, 1);
    putCursor(wtop, wlef+1);
    putCharAttr(BOX_TOP_MID, wcolor, x);
    putCursor(wtop, wlef+x+1);
    putCharAttr(BOX_TOP_RIG, wcolor, 1);
    for (i = 1; i < wbot - wtop; ++i) {      /* draw the sides */
      putCursor(wtop+i, wlef);
      putCharAttr(BOX_MID_LEF, wcolor, 1);
      putCursor(wtop+i, wlef+1);
      putCharAttr(BOX_MID_MID, wcolor, x);
      putCursor(wtop+i, wlef+x+1);
      putCharAttr(BOX_MID_RIG, wcolor, 1);
      }
    putCursor(wbot, wlef);                   /* draw the bottom row */
    putCharAttr(BOX_BOT_LEF, wcolor, 1);
    putCursor(wbot, wlef+1);
    putCharAttr(BOX_BOT_MID, wcolor, x);
    putCursor(wbot, wlef+x+1);
    putCharAttr(BOX_BOT_RIG, wcolor, 1);
    }


static void putStrAttr(short v, short h, char *s, short attr)
  {
    short vOld, hOld;

    getCursor(&vOld, &hOld);
    for ( ; *s; ) {
      putCursor(v, h++);
      putCharAttr(*s++, attr, 1);
      }
    putCursor(vOld, hOld);
    }


static int inKey(void)
  {
    BOOLEAN ok, done;
    short sLen, posX, posY, dx, dy;
    ULONG nextTime;
    char *saveArea;
    int key;

    ok = TRUE;
    sLen = strlen(SAVER_TEXT);
    nextTime = jiffy() + SAVER_DELAY;
    done = FALSE;
    while (!done) {
      if (kbhit()) {
        key = getKey();
        done = TRUE;
        }
      else if (elapsed(nextTime) && ok) {
        saveArea = (char *) malloc(SCREEN_HEIGHT * SCREEN_WIDTH * 2);
        if (saveArea == NULL)
          ok = FALSE;
        else {
          gettext(1, 1, SCREEN_WIDTH, SCREEN_HEIGHT, saveArea);
          cls(0, 0, SCREEN_HEIGHT-1, SCREEN_WIDTH-1, NORMAL);
          posY = 12;
          posX = 39 - (sLen/2);
          dx = dy = 1;
          putStrAttr(posY, posX, SAVER_TEXT, mLow);
          nextTime = jiffy() + SAVER_RATE;
          while (!kbhit()) {
            if (elapsed(nextTime)) {
              putCursor(posY, posX);
              putCharAttr(' ', mLow, sLen);
              posX += dx;
              posY += dy;
              if (posY <= 0 || posY >= SCREEN_HEIGHT-1)
                dy *= -1;
              if (posX <= 0 || posX >= (SCREEN_WIDTH-sLen))
                dx *= -1;
              putStrAttr(posY, posX, SAVER_TEXT, mLow);
              nextTime = jiffy() + SAVER_RATE;
              putCursor(25, 0);
              }
            }
          getKey();
          puttext(1, 1, SCREEN_WIDTH, SCREEN_HEIGHT, saveArea);
          nextTime = jiffy() + SAVER_DELAY;
          free(saveArea);
          }
        }
      }
    return (key);
    }


/* getKey -- waits for a key to be pressed on the keyboard and returns *
 * that character.  Extended characters are properly handled.          */

static int getKey(void)
  {
    _AH = KEYIN;
    geninterrupt(BDOS_REQ);
    if (_AL)
      return (_AL);
    geninterrupt(BDOS_REQ);
    return (_AL | XF);
    }


static ULONG jiffy(void)
  {
    union REGS r;

    r.h.ah = GET_TIME;
    int86(BDOS_REQ, &r, &r);
    return ((ULONG)r.h.dl + ((ULONG)r.h.dh * 100L) + ((ULONG)r.h.cl * 6000L) + ((ULONG)r.h.ch * 360000L));
    }


/* elapsed -- returns TRUE if jtime is less than the current time or if *
 * jtime is greater than 23:00 and current time is less than 1:00.  The *
 * reason for this second criteria is to handle the case of comparing   *
 * the time between midnight.                                           */

static BOOLEAN elapsed(ULONG jtime)
  {
    ULONG jif;

    jif = jiffy();
    return ((jif>jtime) || (jtime>8280000L && jif<360000L));
    }
